from flask import Flask, render_template
import random
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/what')
def what():
    return render_template('what.html')

@app.route('/chto')
def chto():
    return render_template('chto.html')

@app.route('/helpeco')
def helpeco():
    return render_template('helpeco.html')

@app.route('/random1')
def random1():
    random123 = [
        'Глобальное потепление — это постепенное повышение средней температуры Земли из-за выбросов парниковых газов',
        'Выбросы CO₂ от сжигания ископаемого топлива являются основным фактором изменения климата',
        'Ледники тают с ускоренной скоростью, что приводит к повышению уровня мирового океана',
        'Кислотность океанов увеличивается из-за поглощения избыточного CO₂, что угрожает морской жизни',
        'Вырубка лесов уменьшает поглощение углекислого газа, усиливая парниковый эффект',
        'Зеленая энергетика (солнечная, ветровая) помогает снижать углеродный след',
        'Пластиковое загрязнение разрушает экосистемы и угрожает морским животным',
        'Смена климата приводит к более частым и интенсивным ураганам, засухам и пожарам',
        'Биоразнообразие под угрозой из-за утраты мест обитания и изменения климата',
        'Энергосбережение и уменьшение отходов помогают уменьшить воздействие на окружающую среду'
    ]
    random_fact = random.choice(random123)
    return render_template('random1.html', random_fact=random_fact)



if __name__ == '__main__':
    app.run(debug=True)
